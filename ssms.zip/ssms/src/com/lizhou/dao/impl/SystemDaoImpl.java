package com.lizhou.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;

import com.lizhou.bean.Clazz;
import com.lizhou.bean.Grade;
import com.lizhou.bean.Student;
import com.lizhou.dao.inter.SystemDaoInter;
import com.lizhou.tools.MysqlTool;

/**
 * 系统数据层
 * @author bojiangzhou
 *
 */
public class SystemDaoImpl extends BaseDaoImpl implements SystemDaoInter {

	
	
	
	
}
